const {
    Service
} = require('feathers-mongoose');

exports.Taxonomies = class Taxonomies extends Service {

};
